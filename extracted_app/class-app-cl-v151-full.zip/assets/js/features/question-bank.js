/* بانک سؤالات امتحانی — زیرساخت مرحله‌ی ۱
   فقط ثبت، مشاهده، ویرایش و حذف سؤال + دسته‌بندی. (بارگذاری منبع و هوش مصنوعی در مراحل بعد)
   داده‌ها در S.qbk (آرایه) ذخیره می‌شود؛ هر سؤال:
   { id, v:1,               شناسه و نسخه‌ی ساختار (برای مهاجرت در مراحل بعد)
     gr پایه (اول…ششم)، bk کتاب، ls درس، ch فصل، tp مبحث (اختیاری)،
     lv  سطح: 'e' آسان | 'm' متوسط | 'h' سخت،
     ty  نوع: 'mc' چندگزینه‌ای | 'tf' صحیح/غلط | 'fb' جای‌خالی | 'sa' کوتاه‌پاسخ | 'es' تشریحی،
     q   متن سؤال،
     op  گزینه‌ها (فقط mc، آرایه‌ی ۲ تا ۴ متن)،  ok اندیس گزینه‌ی درست (mc) وگرنه -1،
     ans پاسخ (mc: متن گزینه‌ی درست | tf: 'T' یا 'F' | بقیه: متن پاسخ)،
     pt  بارم (عدد)،  src منبع (متن آزاد)،  ca/ua زمان ساخت/ویرایش }
   فقط کلید تازه؛ داده‌ی قبلی تغییری نمی‌کند. فیلدهای ناشناس هنگام ویرایش حفظ می‌شوند. */
(function(){try{
const $=id=>document.getElementById(id);
const E=x=>String(x==null?'':x).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const TY=[['mc','چندگزینه‌ای'],['tf','صحیح / غلط'],['fb','جای‌خالی'],['sa','کوتاه‌پاسخ'],['es','تشریحی']];
const LV=[['e','آسان','#1a8f55'],['m','متوسط','#f0a030'],['h','سخت','#d9534f']];
const LET=['الف','ب','ج','د'];
const tyN=k=>(TY.find(x=>x[0]===k)||[0,'—'])[1];
const lvO=k=>LV.find(x=>x[0]===k)||['','—','#888'];
const grades=()=>typeof GR!=='undefined'?GR:['اول','دوم','سوم','چهارم','پنجم','ششم'];
const list=()=>{S.qbk=Array.isArray(S.qbk)?S.qbk:[];return S.qbk};
const nf=v=>fa(String(v).replace('.','٫'));
const toLat=t=>String(t||'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[٫،,]/g,'.').trim();
const uniq=a=>[...new Set(a.filter(Boolean))].sort((x,y)=>String(x).localeCompare(String(y),'fa'));

const st=document.createElement('style');
st.textContent=`
#qbk .qd-hero{display:flex;gap:12px;flex-wrap:wrap;align-items:center;justify-content:space-between;border-radius:22px;padding:18px;color:#fff;background:linear-gradient(120deg,var(--p),var(--p2));box-shadow:0 10px 26px rgba(0,0,0,.14);margin-bottom:12px}
#qbk .qd-hero h3{margin:0;font-size:19px;color:#fff}#qbk .qd-hero p{margin:4px 0 0;font-size:13px;opacity:.92;line-height:1.8}
#qbk .qd-acts{display:flex;gap:8px;flex-wrap:wrap}
#qbk .qd-btn{width:auto;margin:0;flex:none;border:0;border-radius:14px;padding:10px 16px;font:800 13.5px Vazirmatn,Tahoma,sans-serif;cursor:pointer;background:rgba(255,255,255,.2);color:#fff}
#qbk .qd-btn.p{background:#fff;color:var(--p)}
#qbk .qd-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(62px,1fr));gap:6px;margin:0 0 12px}
#qbk .qd-k{border-radius:16px;padding:9px 2px;text-align:center;background:var(--card);border:1.5px solid var(--line)}
#qbk .qd-k b{display:block;font-size:19px;line-height:1.4}#qbk .qd-k span{font-size:11.5px;color:var(--mut);font-weight:800}
#qbk .qd-sr{width:100%;box-sizing:border-box;margin:0 0 10px;padding:12px 14px;border-radius:16px;font-size:14px}
#qbk .qd-chips{display:flex;gap:7px;flex-wrap:wrap;margin:0 0 12px}
#qbk .qd-chip{width:auto;flex:none;margin:0;border:1.5px solid var(--line);background:var(--card);color:var(--tx);border-radius:999px;padding:6px 14px;font:800 12.5px Vazirmatn,Tahoma,sans-serif;cursor:pointer}
#qbk .qd-chip small{color:var(--mut);margin-right:4px}
#qbk .qd-chip.on{color:#fff;border-color:var(--p);background:linear-gradient(90deg,var(--p),var(--p2))}#qbk .qd-chip.on small{color:#fff;opacity:.85}
#qbk .qd-h{font-weight:800;font-size:14px;margin:4px 2px 8px;color:var(--mut)}
#qbk .qd-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:10px}
#qbk .qd-bk{width:auto;margin:0;text-align:right;display:block;border:1.5px solid var(--line);background:var(--card);color:var(--tx);border-radius:20px;padding:0;overflow:hidden;cursor:pointer;font-family:inherit;box-shadow:0 2px 10px rgba(0,0,0,.05);transition:transform .15s,box-shadow .15s}
#qbk .qd-bk:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(0,0,0,.12)}
#qbk .qd-bt{height:8px}#qbk .qd-bb{padding:12px 12px 12px}
#qbk .qd-ic{width:42px;height:42px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:22px;color:#fff;margin-bottom:8px}
#qbk .qd-bn{font-weight:800;font-size:14px;line-height:1.7;min-height:40px}
#qbk .qd-bm{font-size:12px;color:var(--mut);margin:2px 0 8px;line-height:1.8}
#qbk .qd-bar{display:flex;height:8px;border-radius:99px;overflow:hidden;background:var(--bg2)}#qbk .qd-bar i{display:block;height:100%}
#qbk .qd-bl{display:flex;gap:8px;margin-top:6px;font-size:11.5px;font-weight:800}
#qbk .qd-bk-wrap{position:relative;display:flex;flex-direction:column}
#qbk .qd-bk-wrap .qd-bk{width:100%;height:100%}
#qbk .qd-bk-act{position:absolute;top:8px;left:8px;display:flex;gap:4px;z-index:2}
#qbk .qd-bk-act button{width:auto;margin:0;flex:none;border:1.5px solid rgba(255,255,255,.7);background:rgba(255,255,255,.9);color:var(--tx);border-radius:10px;padding:4px 8px;font:800 11px Vazirmatn,Tahoma,sans-serif;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.08)}
#qbk .qd-bk-act button.dg{color:#d9534f}
#qbk .qd-crumb{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px}
#qbk .qd-back{width:auto;margin:0;flex:none;border:1.5px solid var(--line);background:var(--card);color:var(--tx);border-radius:12px;padding:8px 14px;font:800 13px Vazirmatn,Tahoma,sans-serif;cursor:pointer}
#qbk .qd-tabs{display:flex;gap:7px;overflow-x:auto;padding:2px 0 8px;margin:0 0 6px;scrollbar-width:thin}#qbk .qd-tabs .qd-chip{white-space:nowrap}
#qbk .qd-tools{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:0 0 10px}
#qbk .qd-tools input,#qbk .qd-tools select{width:100%;margin:0;box-sizing:border-box}#qbk .qd-tools .qd-sr{grid-column:1/-1;margin:0}
#qbk .qd-toc{border:1.5px solid var(--line);border-radius:20px;background:var(--card);padding:6px 14px 12px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
#qbk .qd-toch{font-weight:800;font-size:15px;padding:10px 0 6px;color:var(--p)}#qbk .qd-toch small{color:var(--mut);font-weight:700;font-size:12px}
#qbk .qd-tr{display:flex;align-items:baseline;gap:8px;width:100%;margin:0;padding:12px 4px;background:transparent;border:0;border-bottom:1px solid var(--line);border-radius:0;color:var(--tx);text-align:right;font:700 14.5px/1.9 Vazirmatn,Tahoma,sans-serif;cursor:pointer}
#qbk .qd-tr:hover{background:var(--bg2)}
#qbk .qd-tt{flex:0 1 auto;min-width:0}#qbk .qd-tt small{display:inline-block;margin-right:8px;color:var(--mut);font-weight:700;font-size:11.5px}
#qbk .qd-td{flex:1;min-width:18px;border-bottom:2px dotted var(--mut);opacity:.6;transform:translateY(-5px)}
#qbk .qd-tp{flex:none;min-width:48px;text-align:left;font-weight:800;color:var(--p);white-space:nowrap}
#qbk .qd-row{display:flex;align-items:center;gap:4px;border-bottom:1px solid var(--line)}
#qbk .qd-row .qd-tr{flex:1;min-width:0;width:auto;border-bottom:0}
#qbk .qd-row.pk{background:var(--bg2)}
#qbk .qd-ck{flex:none;width:22px;height:22px;margin:0 2px 0 6px;accent-color:var(--p);cursor:pointer}
#qbk .qd-ra{display:flex;gap:4px;flex:none}
#qbk .qd-ra button{width:auto;margin:0;flex:none;border:1.5px solid var(--line);background:var(--card);color:var(--tx);border-radius:10px;padding:5px 9px;font:800 12px Vazirmatn,Tahoma,sans-serif;cursor:pointer}
#qbk .qd-ra button.dg{color:#d9534f}
#qbk .qd-bulk{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0 4px}
#qbk .qd-bulk button{width:auto;margin:0;flex:none;border:1.5px solid var(--line);background:var(--card);color:var(--tx);border-radius:12px;padding:7px 12px;font:800 12.5px Vazirmatn,Tahoma,sans-serif;cursor:pointer}
#qbk .qd-bulk button.dg{background:#d9534f;border-color:#d9534f;color:#fff}
#qbk .qd-bulk button:disabled{opacity:.45;cursor:not-allowed}
#qbk .qd-toca{width:100%;margin:10px 0 0;border:1.5px dashed var(--line);background:transparent;color:var(--p);border-radius:14px;padding:11px;font:800 13.5px Vazirmatn,Tahoma,sans-serif;cursor:pointer}
#qbk .qd-ty{width:auto;margin:0;flex:none;border-radius:999px;padding:6px 12px 6px 30px;font:800 12.5px Vazirmatn,Tahoma,sans-serif}
#qbk .qd-gh{display:flex;align-items:center;gap:8px;margin:14px 2px 8px;font-weight:800;font-size:14px;color:var(--p)}
#qbk .qd-gh:after{content:"";flex:1;height:2px;border-radius:2px;background:var(--line)}#qbk .qd-gh small{color:var(--mut);font-weight:700}
#qbk .qbk-e{padding:11px 12px;margin-bottom:9px;border-radius:16px;border:1.5px solid var(--line);background:var(--card);border-right:5px solid var(--lc,var(--line))}
#qbk .qbk-h{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-weight:800;font-size:13px}
#qbk .qbk-bd{display:inline-block;color:#fff;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:800}
#qbk .qbk-ty{background:var(--bg2);color:var(--p);border-radius:999px;padding:2px 10px;font-size:12px}
#qbk .qbk-pg{margin-right:auto;color:var(--mut);font-size:12px}
#qbk .qbk-p{margin-top:6px;font-size:12.5px;color:var(--mut);font-weight:700;line-height:1.8}
#qbk .qbk-q{margin-top:6px;font-size:14.5px;line-height:1.95;white-space:pre-wrap;word-break:break-word;font-weight:700}
#qbk .qbk-o{margin-top:4px;font-size:13.5px;line-height:1.8;display:flex;gap:6px}
#qbk .qbk-o.ok{color:#1a8f55;font-weight:800}
#qbk .qbk-a{margin-top:6px;font-size:13.5px;line-height:1.9;white-space:pre-wrap;word-break:break-word}
#qbk .qbk-a b{color:#1a8f55}
#qbk .qbk-s{margin-top:4px;font-size:12px;color:var(--mut)}
#qbk .qbk-ac{display:flex;gap:8px;margin-top:8px}#qbk .qbk-ac button{flex:1;margin:0}
#qbk .qbk-em{text-align:center;color:var(--mut);padding:22px 0;font-size:14px;line-height:2.1}
#qbk .qd-more{width:100%;margin:6px 0 0}
#qbk .qd-first{border:2px dashed var(--line);border-radius:22px;padding:26px 16px;text-align:center;line-height:2.1;background:var(--card)}
#qbk .qd-first .qd-acts{justify-content:center;margin-top:10px}#qbk .qd-first .qd-btn{background:linear-gradient(90deg,var(--p),var(--p2));color:#fff}
.pmt-bx .qbk-seg{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.pmt-bx .qbk-seg button,.pmt-bx .qbk-tf button{border:2px solid var(--line);background:var(--card);color:var(--tx);border-radius:12px;padding:9px 4px;font:800 13px Vazirmatn,Tahoma,sans-serif;cursor:pointer}
.pmt-bx .qbk-seg button.on,.pmt-bx .qbk-tf button.on{color:#fff;border-color:var(--p);background:linear-gradient(90deg,var(--p),var(--p2))}
.pmt-bx .qbk-tf{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.pmt-bx .qbk-fl{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
.pmt-bx .qbk-op{display:flex;gap:6px;align-items:center;margin-top:6px}
.pmt-bx .qbk-op button{flex:none;width:42px;height:42px;border:2px solid var(--line);background:var(--card);color:var(--mut);border-radius:12px;font:800 12px Vazirmatn,Tahoma,sans-serif;cursor:pointer;padding:0}
.pmt-bx .qbk-op button.on{background:#1a8f55;border-color:#1a8f55;color:#fff}
.pmt-bx .qbk-op input{flex:1}
`;
document.head.appendChild(st);

const sec=document.createElement('section');sec.id='qbk';
sec.innerHTML='<h2>🗂️ بانک سؤالات امتحانی</h2><div id="qbkMain"></div><p class="sub" id="qbkMsg" style="text-align:right;margin:8px 0 0;min-height:18px"></p>';
const anchor=$('exp')||$('mk')||$('crs')||$('rep');anchor?anchor.after(sec):document.querySelector('main').appendChild(sec);
if(typeof pages!=='undefined'&&!pages.some(q=>q[0]==='qbk'))pages.push(['qbk','🗂️ بانک سؤالات']);

/* ---------- وضعیت نمایش (داشبورد ← کتاب ← سؤال‌ها) ---------- */
const V={sel:false,pick:new Set(),book:'',gf:'',gs:'',lv:'',ty:'',ls:'',s:'',all:false,lim:20};
const PAGE=20;
const bkey=q=>(q.gr||'')+'§'+(q.bk||'');
const gOrd=g=>{const i=grades().indexOf(g);return i<0?99:i};
function books(){const m=new Map();list().forEach(q=>{const k=bkey(q);let b=m.get(k);if(!b){b={key:k,gr:q.gr||'',bk:q.bk||'بدون نام',n:0,e:0,m:0,h:0,ls:new Set()};m.set(k,b)}b.n++;if(b[q.lv]!=null)b[q.lv]++;if(q.ls)b.ls.add(q.ls)});
 return [...m.values()].sort((a,b)=>gOrd(a.gr)-gOrd(b.gr)||a.bk.localeCompare(b.bk,'fa'))}
const hue=k=>{let h=0;for(const c of String(k))h=(h*31+c.charCodeAt(0))%360;return h};
const grad=k=>{const h=hue(k);return `linear-gradient(135deg,hsl(${h},62%,46%),hsl(${(h+40)%360},66%,56%))`};
const bar=b=>{const t=b.n||1;return `<div class="qd-bar">${LV.map(l=>`<i style="width:${(b[l[0]]||0)*100/t}%;background:${l[2]}"></i>`).join('')}</div>`};
const say=t=>{const m=$('qbkMsg');if(m)m.textContent=t||''};
const qHay=q=>[q.q,q.ans,(q.op||[]).join(' '),q.src,q.tp,q.ch,q.ls,q.bk].join(' ');
const qSort=(a,b)=>(a.ln==null?9999:a.ln)-(b.ln==null?9999:b.ln)||(a.p1==null?9999:a.p1)-(b.p1==null?9999:b.p1)||(a.ca||a.id)-(b.ca||b.id);

/* ---------- نمایش سؤال ---------- */
function ansT(x){if(x.ty==='tf')return x.ans==='T'?'صحیح':'غلط';if(x.ty==='mc'){const o=(x.op||[])[x.ok];return o!=null&&o!==''?o:(x.ans||'')}return x.ans||''}
function card(x,full){const l=lvO(x.lv);
 const pg=x.p1!=null?(x.p2!=null&&x.p2!==x.p1?'ص '+fa(x.p1)+' تا '+fa(x.p2):'ص '+fa(x.p1)):'';
 const path=full?[x.gr?'پایه '+x.gr:'',x.bk,x.ls,x.ch?'فصل '+x.ch:'',x.tp].filter(Boolean).map(E).join(' › '):[x.ch?'فصل '+x.ch:'',x.tp?'مبحث: '+x.tp:''].filter(Boolean).map(E).join(' › ');
 let body=`<div class="qbk-q">${E(x.q)}</div>`;
 if(x.ty==='mc')body+=(x.op||[]).map((o,i)=>`<div class="qbk-o${i===x.ok?' ok':''}"><span>${LET[i]||fa(i+1)})</span><span>${E(o)}${i===x.ok?' ✔':''}</span></div>`).join('');
 else body+=`<div class="qbk-a"><b>پاسخ:</b> ${E(ansT(x)||'ثبت نشده')}</div>`;
 return `<div class="qbk-e" style="--lc:${l[2]}"><div class="qbk-h"><span class="qbk-bd" style="background:${l[2]}">${l[1]}</span><span class="qbk-ty">${tyN(x.ty)}</span>${pg?`<span class="qbk-pg">${pg}</span>`:''}</div>
 ${path?`<div class="qbk-p">${path}</div>`:''}${body}${x.src?`<div class="qbk-s">📖 منبع: ${E(x.src)}</div>`:''}
 <div class="qbk-ac"><button class="sm" data-qb="edit" data-i="${x.id}">✏️ ویرایش</button><button class="sm" data-qb="del" data-i="${x.id}">🗑 حذف</button></div></div>`}

/* ---------- داشبورد (صفحه‌ی اول): کتاب‌ها ---------- */
function bookCard(b){const ls=b.ls.size;
 return `<div class="qd-bk-wrap"><button type="button" class="qd-bk" data-qb="book" data-k="${E(b.key)}"><div class="qd-bt" style="background:${grad(b.key)}"></div><div class="qd-bb">
 <div class="qd-ic" style="background:${grad(b.key)}">📘</div><div class="qd-bn">${E(b.bk)}</div>
 <div class="qd-bm">${b.gr?'پایه '+E(b.gr)+' · ':''}${fa(b.n)} سؤال${ls?' · '+fa(ls)+' درس':''}</div>${bar(b)}
 <div class="qd-bl">${LV.map(l=>`<span style="color:${l[2]}">${fa(b[l[0]]||0)} ${l[1]}</span>`).join('')}</div></div></button>
 <div class="qd-bk-act"><button type="button" data-qb="bked" data-k="${E(b.key)}" data-bk="${E(b.bk)}" data-gr="${E(b.gr||'')}" title="ویرایش کتاب">✏️</button><button type="button" class="dg" data-qb="bkdel" data-k="${E(b.key)}" data-bk="${E(b.bk)}" title="حذف کتاب">🗑</button></div></div>`}
function dashHtml(){const A=list(),B=books();
 if(!A.length)return `<div class="qd-first"><div style="font-size:42px">🗂️</div><b style="font-size:16px">بانک سؤال شما هنوز خالی است</b><br>اولین سؤال را ثبت کنید یا سؤال‌های آماده را از فایل Word / PDF / متن وارد کنید.<div class="qd-acts"><button class="qd-btn" data-qb="new">➕ ثبت سؤال جدید</button><button class="qd-btn" data-qb="imp">📥 ورود از فایل</button></div></div>`;
 const kp=(v,t,c)=>`<div class="qd-k"><b${c?` style="color:${c}"`:''}>${fa(v)}</b><span>${t}</span></div>`;
 return `<div class="qd-hero"><div><h3>🗂️ بانک سؤال‌های من</h3><p>یک کتاب را انتخاب کنید تا درس‌ها و سؤال‌هایش نمایش داده شود.</p></div>
 <div class="qd-acts"><button class="qd-btn p" data-qb="new">➕ ثبت سؤال</button><button class="qd-btn" data-qb="imp">📥 ورود از فایل</button><button class="qd-btn" data-qb="build">📝 ساخت برگه</button></div></div>
 <div class="qd-kpis">${kp(A.length,'کل سؤال‌ها','var(--p)')}${kp(B.length,'کتاب')}${LV.map(l=>kp(A.filter(q=>q.lv===l[0]).length,l[1],l[2])).join('')}</div>
 <input id="qbkSrch" class="qd-sr" type="text" placeholder="🔎 جستجو در همه‌ی سؤال‌ها (متن، پاسخ، منبع…)" autocomplete="off" value="${E(V.gs)}">
 <div id="qbkRes"></div>`}
function dashRes(){const box=$('qbkRes');if(!box)return;
 if(V.gs){const R=list().filter(q=>qHay(q).indexOf(V.gs)>=0).sort((a,b)=>(b.ca||b.id)-(a.ca||a.id));
  box.innerHTML=`<div class="qd-h">نتیجه‌ی جستجو: ${fa(R.length)} سؤال</div>`+(R.length?R.slice(0,V.lim).map(q=>card(q,true)).join('')+(R.length>V.lim?`<button class="sm qd-more" data-qb="more">نمایش ${fa(Math.min(PAGE,R.length-V.lim))} سؤال بیشتر</button>`:''):'<div class="qbk-em">سؤالی پیدا نشد.</div>');return}
 const B=books(),gs=[...new Set(B.map(b=>b.gr).filter(Boolean))];
 const vis=B.filter(b=>!V.gf||b.gr===V.gf);
 box.innerHTML=(gs.length>1?`<div class="qd-chips"><button class="qd-chip${V.gf?'':' on'}" data-qb="gf" data-v="">همه‌ی پایه‌ها</button>${gs.map(g=>`<button class="qd-chip${V.gf===g?' on':''}" data-qb="gf" data-v="${E(g)}">پایه ${E(g)}</button>`).join('')}</div>`:'')
  +`<div class="qd-h">کتاب‌ها (${fa(vis.length)})</div><div class="qd-grid">${vis.map(bookCard).join('')}</div>`}

/* ---------- نمای یک کتاب: فهرست درس‌ها (مثل فهرست کتاب) ← سؤال‌های درس ---------- */
function bookQs(){return list().filter(q=>bkey(q)===V.book)}
function lvTyFilter(arr){return arr.filter(q=>(!V.lv||q.lv===V.lv)&&(!V.ty||q.ty===V.ty)&&(!V.s||qHay(q).indexOf(V.s)>=0))}
function groupLs(arr){const m=new Map();arr.forEach(q=>{const k=q.ls||'بدون درس';let g=m.get(k);if(!g){g={name:k,ln:9999,items:[]};m.set(k,g)}if(q.ln!=null&&q.ln<g.ln)g.ln=q.ln;g.items.push(q)});
 const out=[...m.values()].sort((a,b)=>a.ln-b.ln||a.name.localeCompare(b.name,'fa'));out.forEach(g=>g.items.sort(qSort));return out}
/* عنوان درس: اگر خود نام با «درس/فصل…» شروع نشده باشد، شماره‌ی درس جلوی آن می‌آید (بدون تکرار) */
const lsTitle=g=>g.ln<9999&&!/^\s*(درس|فصل|واحد|بخش|مرحله)/.test(g.name)?'درس '+fa(g.ln)+' — '+g.name:g.name;
/* محدوده‌ی صفحه‌ی درس: کمترین «از صفحه» تا بیشترین «تا صفحه»ی سؤال‌های ثبت‌شده */
function pgRange(items){let a=null,b=null;items.forEach(q=>{if(q.p1==null)return;const e=q.p2!=null?q.p2:q.p1;if(a==null||q.p1<a)a=q.p1;if(b==null||e>b)b=e});
 return a==null?'':(a===b?fa(a):fa(a)+' تا '+fa(b))}
function tocHtml(all){const G=groupLs(all),sel=V.sel,n=V.pick.size;
 return `<div class="qd-toc"><div class="qd-toch">📑 فهرست درس‌ها <small>(${fa(G.length)} درس · ${fa(all.length)} سؤال)</small></div>
 <div class="qd-bulk">${sel?`<button type="button" data-qb="pkall">☑️ ${n===G.length?'برداشتن همه':'انتخاب همه'}</button><button type="button" class="dg" data-qb="pkdel"${n?'':' disabled'}>🗑 حذف ${n?fa(n)+' درس انتخاب‌شده':'انتخاب‌شده‌ها'}</button>${n?`<button type="button" data-qb="exp">📤 خروجی ${fa(n)} درس</button>`:''}<button type="button" data-qb="pkoff">انصراف</button>`:`<button type="button" data-qb="pkon">☑️ انتخاب چند درس</button>`}</div>
 ${G.map(g=>{const on=sel&&V.pick.has(g.name);
  return `<div class="qd-row${on?' pk':''}">${sel?`<input type="checkbox" class="qd-ck" data-qb="pk" data-v="${E(g.name)}"${on?' checked':''} aria-label="انتخاب ${E(g.name)}">`:''}<button type="button" class="qd-tr" data-qb="${sel?'pkrow':'ls'}" data-v="${E(g.name)}"><span class="qd-tt">${E(lsTitle(g))}<small>${fa(g.items.length)} سؤال</small></span><span class="qd-td"></span><span class="qd-tp">${pgRange(g.items)||'—'}</span></button>${sel?'':`<span class="qd-ra"><button type="button" data-qb="lsed" data-v="${E(g.name)}" title="ویرایش درس">✏️</button><button type="button" class="dg" data-qb="lsdel" data-v="${E(g.name)}" title="حذف درس">🗑</button></span>`}</div>`}).join('')}
 <button type="button" class="qd-toca" data-qb="all">📚 نمایش همه‌ی ${fa(all.length)} سؤال این کتاب</button></div>`}
function bookHtml(){const b=books().find(x=>x.key===V.book);if(!b){V.book='';return dashHtml()}
 return `<div class="qd-crumb"><button class="qd-back" data-qb="back">→ همه‌ی کتاب‌ها</button><b style="font-size:15px">${E(b.bk)}</b>${b.gr?`<span class="qbk-ty">پایه ${E(b.gr)}</span>`:''}<button class="qd-btn p" data-qb="new" style="background:linear-gradient(90deg,var(--p),var(--p2));color:#fff;margin-right:auto">➕ سؤال در این کتاب</button><button class="qd-btn" data-qb="exp" title="خروجی Word یا PDF، با پاسخ یا بدون پاسخ">📤 خروجی Word / PDF</button></div>
 <div class="qd-kpis">${[['کل',b.n,'var(--p)']].concat(LV.map(l=>[l[1],b[l[0]]||0,l[2]])).map(k=>`<div class="qd-k"><b style="color:${k[2]}">${fa(k[1])}</b><span>${k[0]}</span></div>`).join('')}</div>
 <div class="qd-tools"><input id="qbkSrchB" class="qd-sr" type="text" placeholder="🔎 جستجو در این کتاب…" autocomplete="off" value="${E(V.s)}"></div>
 <div id="qbkCtl"></div>
 <div id="qbkRes"></div>`}
function bookRes(){const ctl=$('qbkCtl'),box=$('qbkRes');if(!box)return;
 const all=bookQs(),filtering=!!(V.lv||V.ty||V.s),toc=!V.ls&&!V.all&&!filtering;
 if(V.ls&&!all.some(q=>(q.ls||'بدون درس')===V.ls))V.ls='';
 const base=all.filter(q=>(!V.ls||(q.ls||'بدون درس')===V.ls)&&(!V.ty||q.ty===V.ty)&&(!V.s||qHay(q).indexOf(V.s)>=0));
 const lvChip=(v,t,n)=>`<button class="qd-chip${V.lv===v?' on':''}" data-qb="lv" data-v="${v}">${t}<small>${fa(n)}</small></button>`;
 const G0=V.ls?groupLs(all.filter(q=>(q.ls||'بدون درس')===V.ls))[0]:null;
 if(ctl)ctl.innerHTML=(toc?'':`<div class="qd-crumb" style="margin-bottom:8px"><button class="qd-back" data-qb="toc">📑 فهرست درس‌ها</button>${G0?`<b style="font-size:14px">${E(lsTitle(G0))}</b>${pgRange(G0.items)?`<span class="qbk-ty">صفحه‌ی ${pgRange(G0.items)}</span>`:''}`:''}</div>`)
  +`<div class="qd-chips">${lvChip('','همه‌ی سطح‌ها',base.length)}${LV.map(l=>lvChip(l[0],l[1],all.filter(q=>q.lv===l[0]&&(!V.ls||(q.ls||'بدون درس')===V.ls)&&(!V.ty||q.ty===V.ty)&&(!V.s||qHay(q).indexOf(V.s)>=0)).length)).join('')}<select data-qf="ty" class="qd-ty"><option value="">همه‌ی انواع</option>${TY.map(x=>`<option value="${x[0]}"${V.ty===x[0]?' selected':''}>${x[1]}</option>`).join('')}</select></div>`;
 if(toc){box.innerHTML=tocHtml(all);return}
 const f=base.filter(q=>!V.lv||q.lv===V.lv),G=groupLs(f);let left=V.lim,html='',total=f.length;
 G.forEach(g=>{if(left<=0)return;const part=g.items.slice(0,left);left-=part.length;
  html+=(V.ls?'':`<div class="qd-gh">${E(lsTitle(g))} <small>(${fa(g.items.length)} سؤال${pgRange(g.items)?' · صفحه‌ی '+pgRange(g.items):''})</small></div>`)+part.map(q=>card(q,false)).join('')});
 box.innerHTML=total?html+(total>V.lim?`<button class="sm qd-more" data-qb="more">نمایش ${fa(Math.min(PAGE,total-V.lim))} سؤال بیشتر (${fa(total-V.lim)} مانده)</button>`:''):'<div class="qbk-em">سؤالی با این فیلترها پیدا نشد.</div>'}

function render(){const m=$('qbkMain');if(!m)return;
 if(V.book&&!books().some(b=>b.key===V.book))V.book='';
 m.innerHTML=V.book?bookHtml():dashHtml();
 V.book?bookRes():dashRes()}

/* ---------- پیشنهاد دسته‌بندی از فهرست درس‌های برنامه + سؤال‌های قبلی ---------- */
const crs=()=>(S.courses||[]).filter(c=>c&&c.name);
const bkOf=()=>uniq(crs().map(c=>c.book).concat(list().map(q=>q.bk)));
const csFor=bk=>crs().filter(c=>!bk||c.book===bk||c.name===bk);
const lsOf=bk=>uniq(csFor(bk).flatMap(c=>(c.ch||[]).map(h=>h&&h.name)).concat(list().filter(q=>!bk||q.bk===bk).map(q=>q.ls)));
const tpOf=(bk,ls)=>uniq(csFor(bk).flatMap(c=>(c.ch||[]).filter(h=>h&&(!ls||h.name===ls)).flatMap(h=>(h.tp||[]).map(t=>t&&t.name))).concat(list().filter(q=>(!bk||q.bk===bk)&&(!ls||q.ls===ls)).map(q=>q.tp)));
const dl=(id,a)=>`<datalist id="${id}">${a.map(v=>`<option value="${E(v)}">`).join('')}</datalist>`;
function refreshDL(){const bk=($('qfB')||{}).value||'',ls=($('qfL')||{}).value||'';
 $('qfBL').innerHTML=bkOf().map(v=>`<option value="${E(v)}">`).join('');$('qfLL').innerHTML=lsOf(bk.trim()).map(v=>`<option value="${E(v)}">`).join('');$('qfPL').innerHTML=tpOf(bk.trim(),ls.trim()).map(v=>`<option value="${E(v)}">`).join('')}

/* ---------- فرم ---------- */
const ov=document.createElement('div');ov.className='pmt-ov';ov.id='qbkOv';ov.innerHTML='<div class="pmt-bx" role="dialog" aria-modal="true"></div>';document.body.appendChild(ov);
let ed=null,LAST={};
function formHtml(){const g=grades();
 return `<h3>${ed.id?'✏️ ویرایش سؤال':'🗂️ ثبت سؤال جدید'}</h3>
 <label>پایه</label><select id="qfG"><option value="">انتخاب کنید</option>${g.map(x=>`<option value="${x}"${(ed.gr||(S.prof&&S.prof.grade)||'')===x?' selected':''}>پایه ${x}</option>`).join('')}</select>
 <label>کتاب</label><input id="qfB" list="qfBL" value="${E(ed.bk)}" placeholder="مثلاً کتاب فارسی پایه چهارم" autocomplete="off">
 <label>درس</label><input id="qfL" list="qfLL" value="${E(ed.ls)}" placeholder="نام درس یا فصل" autocomplete="off">
 <label>فصل (اختیاری)</label><input id="qfC" value="${E(ed.ch||'')}" placeholder="مثلاً فصل دوم" autocomplete="off">
 <label>مبحث (اختیاری)</label><input id="qfP" list="qfPL" value="${E(ed.tp)}" placeholder="مثلاً نگارش، دستور، ضرب" autocomplete="off">
 <label>شماره‌ی درس (اختیاری؛ برای انتخاب محدوده‌ی امتحان)</label><input id="qfLn" type="text" inputmode="numeric" value="${E(ed.ln)}" placeholder="مثلاً ۳" autocomplete="off">
 <label>صفحه‌ی کتاب (اختیاری)</label><div class="qbk-fl"><input id="qfP1" type="text" inputmode="numeric" value="${E(ed.p1)}" placeholder="از صفحه" autocomplete="off"><input id="qfP2" type="text" inputmode="numeric" value="${E(ed.p2)}" placeholder="تا صفحه (اگر یک صفحه است خالی بگذارید)" autocomplete="off"></div>
 ${dl('qfBL',[])}${dl('qfLL',[])}${dl('qfPL',[])}
 <label>سطح دشواری</label><div class="qbk-seg" id="qfLv">${LV.map(l=>`<button type="button" data-qb="lv" data-v="${l[0]}" class="${ed.lv===l[0]?'on':''}">${l[1]}</button>`).join('')}</div>
 <label>نوع سؤال</label><select id="qfT">${TY.map(t=>`<option value="${t[0]}"${ed.ty===t[0]?' selected':''}>${t[1]}</option>`).join('')}</select>
 <label>متن سؤال</label><textarea id="qfQ" style="min-height:96px">${E(ed.q)}</textarea>
 <div id="qfMc"><label>گزینه‌ها (اختیاری؛ در صورت داشتن پاسخ صحیح، دکمه‌ی کنار گزینه را بزنید)</label>${[0,1,2,3].map(i=>`<div class="qbk-op"><button type="button" data-qb="ok" data-i="${i}" class="${ed.ok===i?'on':''}">${LET[i]}</button><input id="qfO${i}" value="${E(ed.op[i]||'')}" placeholder="گزینه‌ی ${LET[i]}" autocomplete="off"></div>`).join('')}</div>
 <div id="qfTf"><label>پاسخ درست (اختیاری)</label><div class="qbk-tf"><button type="button" data-qb="tf" data-v="T" class="${ed.tfv==='T'?'on':''}">صحیح</button><button type="button" data-qb="tf" data-v="F" class="${ed.tfv==='F'?'on':''}">غلط</button></div></div>
 <div id="qfAn"><label>پاسخ (اختیاری)</label><textarea id="qfA">${E(ed.ans)}</textarea></div>
 <label>منبع (اختیاری)</label><input id="qfR" value="${E(ed.src)}" placeholder="مثلاً کتاب درسی صفحه‌ی ۴۲ یا طرح معلم" autocomplete="off">
 <div class="pmt-er" id="qfEr"></div>
 <div class="pmt-fa"><button class="go" type="button" data-qb="save">💾 ${ed.id?'ذخیره‌ی تغییرات':'ثبت در بانک'}</button><button type="button" data-qb="cancel">انصراف</button></div>`}
function togType(){const t=$('qfT').value;$('qfMc').hidden=t!=='mc';$('qfTf').hidden=t!=='tf';$('qfAn').hidden=t==='mc'||t==='tf'}
function openForm(id){
 ed={id:id||0,gr:'',bk:'',ls:'',ch:'',tp:'',ln:'',p1:'',p2:'',lv:'',ty:'mc',q:'',op:['','','',''],ok:-1,tfv:'',ans:'',pt:'1',src:''};
 if(id){const x=list().find(q=>q.id===id);if(!x)return;
  Object.assign(ed,{gr:x.gr||'',bk:x.bk||'',ls:x.ls||'',ch:x.ch||'',tp:x.tp||'',ln:x.ln==null?'':String(x.ln),p1:x.p1==null?'':String(x.p1),p2:x.p2==null?'':String(x.p2),lv:x.lv||'',ty:x.ty||'mc',q:x.q||'',pt:String(x.pt==null?1:x.pt),src:x.src||''});
  if(x.ty==='mc'){(x.op||[]).slice(0,4).forEach((o,i)=>{ed.op[i]=o});ed.ok=typeof x.ok==='number'?x.ok:-1}
  else if(x.ty==='tf')ed.tfv=x.ans==='T'||x.ans==='F'?x.ans:'';else ed.ans=x.ans||''}
 else{ed.gr=LAST.gr||(S.prof&&S.prof.grade)||'';ed.bk=LAST.bk||'';ed.ls=LAST.ls||'';ed.ch=LAST.ch||'';ed.tp=LAST.tp||'';ed.ln=LAST.ln||'';ed.lv=LAST.lv||'';ed.ty=LAST.ty||'mc';ed.pt=LAST.pt||'1'}
 ov.firstElementChild.innerHTML=formHtml();togType();refreshDL();ov.classList.add('on')}
const closeForm=()=>{ov.classList.remove('on');ed=null};
function saveForm(){const er=t=>{$('qfEr').textContent=t},v=id=>$(id).value.trim();
 const gr=$('qfG').value,bk=v('qfB'),ls=v('qfL'),ch=v('qfC'),tp=v('qfP'),ty=$('qfT').value,q=v('qfQ'),src=v('qfR');
 if(!gr){er('پایه را انتخاب کنید.');$('qfG').focus();return}
 if(!bk){er('کتاب را بنویسید.');$('qfB').focus();return}
 if(!ls){er('درس را بنویسید.');$('qfL').focus();return}
 if(!ed.lv){er('سطح دشواری را انتخاب کنید.');return}
 if(!q){er('متن سؤال را بنویسید.');$('qfQ').focus();return}
 const pt=parseFloat(ed.pt)>0?parseFloat(ed.pt):1; /* ابتدایی: ارزشیابی توصیفی؛ بارم نمایش/دریافت نمی‌شود */
 const nz=id=>{const t=toLat(v(id));if(!t)return{ok:true,n:null};return /^\d{1,4}$/.test(t)&&+t>0?{ok:true,n:+t}:{ok:false}};
 const rLn=nz('qfLn'),rP1=nz('qfP1'),rP2=nz('qfP2');
 if(!rLn.ok){er('شماره‌ی درس باید یک عدد صحیح مثبت باشد (یا خالی بماند).');$('qfLn').focus();return}
 if(!rP1.ok||!rP2.ok){er('شماره‌ی صفحه باید عدد صحیح مثبت باشد (یا خالی بماند).');return}
 if(rP2.n!=null&&rP1.n==null){er('اگر «تا صفحه» را نوشته‌اید، «از صفحه» را هم بنویسید.');$('qfP1').focus();return}
 if(rP1.n!=null&&rP2.n!=null&&rP2.n<rP1.n){er('«تا صفحه» نباید کوچک‌تر از «از صفحه» باشد.');$('qfP2').focus();return}
 let op=[],ok=-1,ans='';
 if(ty==='mc'){const raw=[0,1,2,3].map(i=>v('qfO'+i));raw.forEach((o,i)=>{if(o){if(i===ed.ok)ok=op.length;op.push(o)}});
  if(op.length<2){er('دست‌کم دو گزینه بنویسید.');return}
  if(ok>=0)ans=op[ok]}
 else if(ty==='tf'){ans=(ed.tfv==='T'||ed.tfv==='F')?ed.tfv:''}
 else{ans=v('qfA')}
 const rec={v:1,gr,bk,ls,ch,tp,lv:ed.lv,ty,q,op,ok,ans,pt,src},L=list(),now=Date.now();
 if(rLn.n!=null)rec.ln=rLn.n;if(rP1.n!=null){rec.p1=rP1.n;rec.p2=rP2.n!=null?rP2.n:rP1.n}
 if(ed.id){const x=L.find(o=>o.id===ed.id);if(!x){closeForm();return}if(rec.ln==null)delete x.ln;if(rec.p1==null){delete x.p1;delete x.p2}Object.assign(x,rec,{ua:now})}
 else{let id=now;const u=new Set(L.map(o=>o.id));while(u.has(id))id++;L.push(Object.assign({id},rec,{ca:now}))}
 LAST={gr,bk,ls,ch,tp,ln:rLn.n!=null?String(rLn.n):'',lv:ed.lv,ty,pt:String(pt)};
 save();closeForm();render();say('✅ سؤال ذخیره شد')}
ov.addEventListener('click',e=>{const t=e.target;if(t===ov){closeForm();return}
 const a=t.closest('[data-qb]');if(!a||!ed)return;const k=a.dataset.qb;
 if(k==='cancel')closeForm();else if(k==='save')saveForm();
 else if(k==='lv'){ed.lv=a.dataset.v;ov.querySelectorAll('[data-qb="lv"]').forEach(b=>b.classList.toggle('on',b===a))}
 else if(k==='ok'){ed.ok=ed.ok===+a.dataset.i?-1:+a.dataset.i;ov.querySelectorAll('[data-qb="ok"]').forEach(b=>b.classList.toggle('on',+b.dataset.i===ed.ok))}
 else if(k==='tf'){ed.tfv=a.dataset.v;ov.querySelectorAll('[data-qb="tf"]').forEach(b=>b.classList.toggle('on',b===a))}});
ov.addEventListener('change',e=>{if(ed&&e.target.id==='qfT')togType()});
ov.addEventListener('input',e=>{if(ed&&(e.target.id==='qfB'||e.target.id==='qfL'))refreshDL()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(ov.classList.contains('on'))closeForm();if(typeof lov!=='undefined'&&lov.classList.contains('on'))closeLs()}});

/* ---------- ویرایش / حذف درس (همه‌ی سؤال‌های همان درس در کتاب جاری) ---------- */
const lsKey=q=>q.ls||'بدون درس';
const inLs=(name)=>list().filter(q=>bkey(q)===V.book&&lsKey(q)===name);
const lov=document.createElement('div');lov.className='pmt-ov';lov.id='qbkLsOv';lov.innerHTML='<div class="pmt-bx" role="dialog" aria-modal="true"></div>';document.body.appendChild(lov);
let led=null;
function openLsEdit(name){const items=inLs(name);if(!items.length)return;
 const g=groupLs(items)[0],lns=[...new Set(items.map(q=>q.ln).filter(x=>x!=null))];
 let a=null,b=null;items.forEach(q=>{if(q.p1==null)return;const e=q.p2!=null?q.p2:q.p1;if(a==null||q.p1<a)a=q.p1;if(b==null||e>b)b=e});
 led={name,n:items.length,p1:a==null?'':String(a),p2:a==null||b===a?'':String(b),ln:g.ln<9999?String(g.ln):'',multiLn:lns.length>1};
 lov.firstElementChild.innerHTML=`<h3>✏️ ویرایش درس</h3><p class="sub" style="text-align:right;margin:0 0 6px;line-height:1.9">تغییرات روی همه‌ی ${fa(items.length)} سؤال این درس اعمال می‌شود.</p>
 <label>نام درس</label><input id="qlN" value="${E(name==='بدون درس'?'':name)}" placeholder="نام درس" autocomplete="off">
 <label>شماره‌ی درس (اختیاری)</label><input id="qlLn" type="text" inputmode="numeric" value="${E(led.ln)}" placeholder="مثلاً ۳" autocomplete="off">
 <label>محدوده‌ی صفحه‌ی درس (اختیاری)</label><div class="qbk-fl"><input id="qlP1" type="text" inputmode="numeric" value="${E(led.p1)}" placeholder="از صفحه" autocomplete="off"><input id="qlP2" type="text" inputmode="numeric" value="${E(led.p2)}" placeholder="تا صفحه (اگر یک صفحه است خالی)" autocomplete="off"></div>
 <p class="sub" style="text-align:right;margin:6px 0 0;line-height:1.9;font-size:12px">اگر محدوده‌ی صفحه را تغییر دهید، برای همه‌ی سؤال‌های این درس ثبت می‌شود؛ اگر دست نزنید، صفحه‌ی هر سؤال همان‌طور که هست می‌ماند. اگر نام را با درس دیگری یکسان کنید، دو درس ادغام می‌شوند.</p>
 <div class="pmt-er" id="qlEr"></div>
 <div class="pmt-fa"><button class="go" type="button" data-ql="save">💾 ذخیره‌ی تغییرات</button><button type="button" data-ql="cancel">انصراف</button></div>`;
 lov.classList.add('on')}
const closeLs=()=>{lov.classList.remove('on');led=null};
function saveLsEdit(){if(!led)return;const er=t=>{$('qlEr').textContent=t},v=id=>$(id).value.trim();
 const name=v('qlN');if(!name){er('نام درس را بنویسید.');$('qlN').focus();return}
 const nz=id=>{const t=toLat(v(id));if(!t)return{ok:true,n:null};return /^\d{1,4}$/.test(t)&&+t>0?{ok:true,n:+t}:{ok:false}};
 const rLn=nz('qlLn'),r1=nz('qlP1'),r2=nz('qlP2');
 if(!rLn.ok){er('شماره‌ی درس باید یک عدد صحیح مثبت باشد (یا خالی بماند).');$('qlLn').focus();return}
 if(!r1.ok||!r2.ok){er('شماره‌ی صفحه باید عدد صحیح مثبت باشد (یا خالی بماند).');return}
 if(r2.n!=null&&r1.n==null){er('اگر «تا صفحه» را نوشته‌اید، «از صفحه» را هم بنویسید.');$('qlP1').focus();return}
 if(r1.n!=null&&r2.n!=null&&r2.n<r1.n){er('«تا صفحه» نباید کوچک‌تر از «از صفحه» باشد.');$('qlP2').focus();return}
 const items=inLs(led.name);if(!items.length){closeLs();return}
 const merge=name!==led.name&&name!==(led.name==='بدون درس'?'':led.name)&&list().some(q=>bkey(q)===V.book&&lsKey(q)===name);
 if(merge&&!confirm('درسی با نام «'+name+'» از قبل در این کتاب هست. سؤال‌های این دو درس در هم ادغام شوند؟'))return;
 const oldLn=led.ln,oldP1=led.p1,oldP2=led.p2,now=Date.now();
 const lnCh=(rLn.n==null?'':String(rLn.n))!==oldLn,pgCh=(r1.n==null?'':String(r1.n))!==oldP1||(r2.n==null?'':String(r2.n))!==oldP2;
 items.forEach(q=>{q.ls=name;
  if(lnCh){if(rLn.n==null)delete q.ln;else q.ln=rLn.n}
  if(pgCh){if(r1.n==null){delete q.p1;delete q.p2}else{q.p1=r1.n;q.p2=r2.n!=null?r2.n:r1.n}}
  q.ua=now});
 if(V.ls===led.name)V.ls=name;
 save();closeLs();render();say('✅ درس «'+name+'» ذخیره شد'+(merge?' (ادغام شد)':''))}
lov.addEventListener('click',e=>{const t=e.target;if(t===lov){closeLs();return}const a=t.closest('[data-ql]');if(!a)return;if(a.dataset.ql==='cancel')closeLs();else if(a.dataset.ql==='save')saveLsEdit()});
lov.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.tagName==='INPUT'){e.preventDefault();saveLsEdit()}});

/* ---------- ویرایش / حذف کتاب (همه‌ی سؤال‌های همان کتاب) ---------- */
const bov=document.createElement('div');bov.className='pmt-ov';bov.id='qbkBookOv';bov.innerHTML='<div class="pmt-bx" role="dialog" aria-modal="true"></div>';document.body.appendChild(bov);
let bed=null;
function openBookEdit(key,bk,gr){const items=list().filter(q=>bkey(q)===key);if(!items.length)return;
  bed={key,oldBk:bk,oldGr:gr,n:items.length};
  bov.firstElementChild.innerHTML=`<h3>✏️ ویرایش کتاب</h3><p class="sub" style="text-align:right;margin:0 0 6px;line-height:1.9">تغییرات روی همه‌ی ${fa(items.length)} سؤال این کتاب اعمال می‌شود.</p>
  <label>نام کتاب</label><input id="qbN" value="${E(bk)}" placeholder="نام کتاب" autocomplete="off">
  <label>پایه (اختیاری)</label><input id="qbG" value="${E(gr||'')}" placeholder="مثلاً چهارم" autocomplete="off">
  <div class="pmt-er" id="qbEr"></div>
  <div class="pmt-fa"><button class="go" type="button" data-qbov="save">💾 ذخیره‌ی تغییرات</button><button type="button" data-qbov="cancel">انصراف</button></div>`;
  bov.classList.add('on')}
const closeBook=()=>{bov.classList.remove('on');bed=null};
function saveBookEdit(){if(!bed)return;const er=t=>{$('qbEr').textContent=t},v=id=>$(id).value.trim();
  const name=v('qbN');const g=v('qbG');
  if(!name){er('نام کتاب را بنویسید.');$('qbN').focus();return}
  const items=list().filter(q=>bkey(q)===bed.key);if(!items.length){closeBook();return}
  const merge=name!==bed.oldBk&&list().some(q=>q.bk===name&&(q.gr||'')===(g||'')&&bkey(q)!==bed.key);
  if(merge&&!confirm('کتابی با نام «'+name+'» و همین پایه از قبل هست. سؤال‌های این دو کتاب در هم ادغام شوند؟'))return;
  const now=Date.now();
  items.forEach(q=>{q.bk=name;if(g==='')delete q.gr;else q.gr=g;q.ua=now});
  if(V.book===bed.key)V.book=name+'§'+(g||'');
  save();closeBook();render();say('✅ کتاب «'+name+'» ذخیره شد'+(merge?' (ادغام شد)':''))}
bov.addEventListener('click',e=>{const t=e.target;if(t===bov){closeBook();return}const a=t.closest('[data-qbov]');if(!a)return;if(a.dataset.qbov==='cancel')closeBook();else if(a.dataset.qbov==='save')saveBookEdit()});
bov.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.tagName==='INPUT'){e.preventDefault();saveBookEdit()}});

function delBook(key,bk){const hit=list().filter(q=>bkey(q)===key);if(!hit.length)return;
  const msg='کتاب «'+bk+'» به همراه '+fa(hit.length)+' سؤال و پاسخ‌هایش حذف شود؟';
  if(!confirm(msg+'\nاین کار قابل بازگشت نیست (پیشنهاد: قبل از حذف پشتیبان بگیرید).'))return;
  const ids=new Set(hit.map(q=>q.id));S.qbk=list().filter(q=>!ids.has(q.id));
  if(V.book===key)V.book='';save();render();say('🗑 کتاب «'+bk+'» و '+fa(hit.length)+' سؤال حذف شد')}

function delLessons(names){const set=new Set(names);
 const hit=list().filter(q=>bkey(q)===V.book&&set.has(lsKey(q)));if(!hit.length)return;
 const msg=names.length===1?'درس «'+names[0]+'» به همراه '+fa(hit.length)+' سؤال و پاسخ‌هایش حذف شود؟':fa(names.length)+' درس انتخاب‌شده به همراه '+fa(hit.length)+' سؤال و پاسخ‌هایشان حذف شود؟';
 if(!confirm(msg+'\nاین کار قابل بازگشت نیست (پیشنهاد: قبل از حذف پشتیبان بگیرید).'))return;
 const ids=new Set(hit.map(q=>q.id));S.qbk=list().filter(q=>!ids.has(q.id));
 V.pick.clear();V.sel=false;V.ls='';save();render();say('🗑 '+fa(names.length)+' درس و '+fa(hit.length)+' سؤال حذف شد')}

/* ---------- رویدادهای صفحه ---------- */
sec.addEventListener('click',e=>{const b=e.target.closest('[data-qb]');if(!b)return;const k=b.dataset.qb;
 if(k==='new'){say('');if(V.book){const bk=books().find(x=>x.key===V.book);if(bk){LAST.gr=bk.gr;LAST.bk=bk.bk}}openForm()}
 else if(k==='edit'){say('');openForm(+b.dataset.i)}
 else if(k==='del'){if(!confirm('این سؤال از بانک حذف شود؟ این کار قابل بازگشت نیست.'))return;S.qbk=list().filter(x=>x.id!==+b.dataset.i);save();render();say('🗑 سؤال حذف شد')}
 else if(k==='book'){V.sel=false;V.pick.clear();V.book=b.dataset.k;V.lv='';V.ty='';V.ls='';V.s='';V.all=false;V.lim=PAGE;say('');render();window.scrollTo({top:sec.offsetTop-10,behavior:'smooth'})}
 else if(k==='back'){V.sel=false;V.pick.clear();V.book='';V.gs='';V.lim=PAGE;say('');render()}
 else if(k==='gf'){V.gf=b.dataset.v;dashRes()}
 else if(k==='lv'){V.lv=b.dataset.v;V.lim=PAGE;bookRes()}
 else if(k==='ls'){V.ls=b.dataset.v;V.all=false;V.lim=PAGE;render()}
 else if(k==='all'){V.all=true;V.ls='';V.lim=PAGE;bookRes()}
 else if(k==='toc'){V.ls='';V.all=false;V.lv='';V.ty='';V.s='';V.lim=PAGE;render()}
 else if(k==='more'){V.lim+=PAGE;V.book?bookRes():dashRes()}
 else if(k==='lsed'){say('');openLsEdit(b.dataset.v)}
 else if(k==='lsdel'){delLessons([b.dataset.v])}
 else if(k==='bked'){say('');openBookEdit(b.dataset.k,b.dataset.bk,b.dataset.gr||'')}
 else if(k==='bkdel'){delBook(b.dataset.k,b.dataset.bk)}
 else if(k==='pkon'){V.sel=true;V.pick.clear();bookRes()}
 else if(k==='pkoff'){V.sel=false;V.pick.clear();bookRes()}
 else if(k==='pkall'){const G=groupLs(bookQs());if(V.pick.size===G.length)V.pick.clear();else G.forEach(g=>V.pick.add(g.name));bookRes()}
 else if(k==='pk'||k==='pkrow'){const n=b.dataset.v;if(V.pick.has(n))V.pick.delete(n);else V.pick.add(n);bookRes()}
 else if(k==='pkdel'){if(V.pick.size)delLessons([...V.pick])}
 else if(k==='exp'){const bk=books().find(x=>x.key===V.book);if(!bk)return;const go=()=>QEXP.open({key:bk.key,gr:bk.gr,bk:bk.bk,ls:V.ls||'',pick:V.sel?[...V.pick]:[]});if(window.QEXP){go();return}/* اگر ماژول از فهرست بارگذاری جا افتاده یا کش قدیمی است، مستقیم و یک‌بار بارگذاری می‌شود */const sc=document.createElement('script');sc.src='assets/js/features/question-export.js?v='+Date.now();sc.onload=()=>{if(window.QEXP)go();else say('⚠️ ماژول خروجی بارگذاری نشد؛ صفحه را یک بار تازه کنید.')};sc.onerror=()=>say('⚠️ فایل assets/js/features/question-export.js روی سایت پیدا نشد؛ آن را در گیت‌هاب آپلود کنید.');document.body.appendChild(sc)}
 else if(k==='imp'){if(typeof show==='function')show('qimp')}
 else if(k==='build'){if(typeof show==='function')show('exb')}});
sec.addEventListener('change',e=>{if(e.target.dataset&&e.target.dataset.qf==='ty'){V.ty=e.target.value;V.lim=PAGE;bookRes()}});
sec.addEventListener('input',e=>{
 if(e.target.id==='qbkSrch'){V.gs=e.target.value.trim();V.lim=PAGE;dashRes()}
 else if(e.target.id==='qbkSrchB'){V.s=e.target.value.trim();V.lim=PAGE;bookRes()}});

const _s=window.show;window.show=function(id){const r=_s.apply(this,arguments);try{if(id==='qbk')render()}catch(e){console.error('qbk',e)}return r};
window.QBK={open:openForm,all:()=>list().slice(),render};
}catch(e){console.error('question-bank',e)}})();
